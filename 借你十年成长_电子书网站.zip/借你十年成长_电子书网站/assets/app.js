const root=document.documentElement, body=document.body, sidebar=document.querySelector('.sidebar');
const saved=localStorage.getItem('book-theme'); if(saved==='dark') body.classList.add('dark');
document.getElementById('theme').onclick=()=>{body.classList.toggle('dark');localStorage.setItem('book-theme',body.classList.contains('dark')?'dark':'light')};
let size=Number(localStorage.getItem('book-size')||19); function setSize(v){size=Math.max(15,Math.min(25,v));root.style.setProperty('--font-size',size+'px');localStorage.setItem('book-size',size)}
document.getElementById('smaller').onclick=()=>setSize(size-1);document.getElementById('larger').onclick=()=>setSize(size+1);setSize(size);
const menu=document.getElementById('menu'), readerMenu=document.getElementById('readerMenu');
function toggleMenu(){sidebar.classList.toggle('open')}; menu.onclick=toggleMenu; readerMenu.onclick=toggleMenu;
document.querySelectorAll('.toc a').forEach(a=>a.onclick=()=>sidebar.classList.remove('open'));
const bar=document.querySelector('.progress'); addEventListener('scroll',()=>{let d=document.documentElement;let ratio=d.scrollTop/(d.scrollHeight-d.clientHeight);bar.style.width=(100*Math.max(0,ratio))+'%';localStorage.setItem('book-scroll',d.scrollTop)},{passive:true});
const toast=document.getElementById('toast');let toastTimer;function notify(text){toast.textContent=text;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),1600)}
const q=document.getElementById('search');q.addEventListener('input',()=>{document.querySelectorAll('mark').forEach(m=>m.replaceWith(m.textContent));let s=q.value.trim();if(!s)return;let nodes=[...document.querySelectorAll('.book [data-search]')].filter(x=>x.textContent.includes(s));if(nodes[0])nodes[0].scrollIntoView({behavior:'smooth',block:'center'});nodes.slice(0,30).forEach(n=>{n.innerHTML=n.textContent.replaceAll(s,'<mark>'+s+'</mark>')});notify(nodes.length?`找到 ${nodes.length} 处相关内容`:'没有找到相关内容')});
const headings=[...document.querySelectorAll('.book [id]')], links=[...document.querySelectorAll('.toc a')], current=document.getElementById('currentChapter');
let currentId='自序';
const io=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){currentId=e.target.id;links.forEach(a=>a.classList.toggle('active',a.hash==='#'+e.target.id));current.textContent=e.target.textContent.trim().slice(0,32);localStorage.setItem('book-last-id',e.target.id);localStorage.setItem('book-last-title',current.textContent);syncBookmarkButton()}})},{rootMargin:'-12% 0px -78%'});headings.forEach(h=>io.observe(h));
const lastId=localStorage.getItem('book-last-id'), lastTitle=localStorage.getItem('book-last-title'), lastText=document.getElementById('lastReadText');
if(lastId&&lastTitle){lastText.innerHTML=`上次读到：<a href="#${lastId}">${lastTitle}</a>`;lastText.querySelector('a').style.color='inherit'}
let bookmarks=JSON.parse(localStorage.getItem('book-bookmarks')||'[]');const bookmarkBtn=document.getElementById('bookmark');
function syncBookmarkButton(){const saved=bookmarks.includes(currentId);bookmarkBtn.classList.toggle('saved',saved);bookmarkBtn.textContent=saved?'♥':'♡';bookmarkBtn.setAttribute('aria-label',saved?'取消收藏当前篇目':'收藏当前篇目');links.forEach(a=>a.classList.toggle('bookmarked',bookmarks.includes(decodeURIComponent(a.hash.slice(1)))))}
bookmarkBtn.onclick=()=>{if(bookmarks.includes(currentId)){bookmarks=bookmarks.filter(x=>x!==currentId);notify('已取消收藏')}else{bookmarks.push(currentId);notify('已收藏这一篇')}localStorage.setItem('book-bookmarks',JSON.stringify(bookmarks));syncBookmarkButton()};syncBookmarkButton();
const readable=headings.filter(h=>h.classList.contains('heading')&&!h.textContent.includes('妈妈有话说')&&!h.textContent.includes('拾遗'));
document.getElementById('randomRead').onclick=()=>{const target=readable[Math.floor(Math.random()*readable.length)];if(target){target.scrollIntoView({behavior:'smooth',block:'start'});history.replaceState(null,'','#'+target.id);notify('为你翻到一篇文字')}};
addEventListener('keydown',e=>{if(e.key==='Escape')sidebar.classList.remove('open');if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='f'){e.preventDefault();q.focus();q.select()}});
